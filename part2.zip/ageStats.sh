#!/bin/bash


awk 'BEGIN {print "Female #:" }'
awk '/$7!= "Male|Female/' formatData.csv |less -S |  wc -l


awk 'BEGIN { print "Male #:" }'
awk '/$7!= "Female|Male/ ' formatData.csv |less -S |  wc -l



awk '/$7!= "Male|Female/{ total += $6; count++ }
END { print "Average Female Age: " total/count }' formatData.csv

awk '/$7!= "Female|Male/{ total += $6; count++ }
END { print "Average Male Age: " total/count }' formatData.csv




awk 'BEGIN { print "White Female total: "}'
awk '{ if(($8=="White" && $7 =="Female") ) print  }' formatData.csv | less -S | wc -l

awk 'BEGIN {print "Black Female Total:" }'
awk '{ if( ($8=="Black" && $7 =="Female") ) print  }' formatData.csv | less -S | wc -l

awk 'BEGIN {print "Black Male Total: "}'
awk '{ if( ($8=="Black" && $7 == "Male") ) print  }' formatData.csv | less -S | wc -l

awk 'BEGIN { print "White Male Total: "}'
awk '{ if(($8=="White" && $7 =="Male")) print }' formatData.csv | less -S | wc -l



awk 'BEGIN {print "White Female average Age:" }'
awk '{ total += $1; counter++ } END { print total/counter }' WhiteFemale.txt

awk 'BEGIN {print "Black Female average Age:" }'
awk '{ total += $1; counter++ } END { print total/counter }' BlackFemales.txt

awk 'BEGIN {print "Black  Male average Age:" }'
awk '{ total += $1; counter++ } END { print total/counter }' BlackMales.txt



awk 'BEGIN {print "White Male average Age:" }'
awk '{ total += $1; counter++ } END { print total/counter }' WhtieMales.txt




awk 'BEGIN {print "White Female min  Age:" }'
awk 'BEGIN{holder=1000}{if ($1<0+holder) holder=$1} END{print holder}' WhiteFemale.txt

awk 'BEGIN {print "White Female max Age:" }'
awk 'BEGIN{holder=0}{if ($1>0+holder) holder=$1} END{print holder}' WhiteFemale.txt

awk 'BEGIN {print "Black Female min  Age:" }'
awk 'BEGIN{holder=1000}{if ($1<0+holder) holder=$1} END{print holder}' BlackFemales.txt

awk 'BEGIN {print "Black Female max Age:" }'
awk 'BEGIN{holder=0}{if ($1>0+holder) holder=$1} END{print holder}' BlackFemales.txt

awk 'BEGIN {print "Black Male min Age:" }'
awk 'BEGIN{holder=1000}{if ($1<0+holder) holder=$1} END{print holder}' BlackMales.txt

awk 'BEGIN {print "Black Male max Age:" }'
awk 'BEGIN{holder= 0}{if ($1>0+holder) holder=$1} END{print holder}' BlackMales.txt

awk 'BEGIN {print "White Male min Age:" }'
awk 'BEGIN{holder=1000}{if ($1<0+holder) holder=$1} END{print holder}' WhtieMales.txt

awk 'BEGIN {print "White Male max Age:" }'
awk 'BEGIN{holder= 0}{if ($1>0+holder) holder=$1} END{print holder}' WhtieMales.txt










